@echo off
title WINDOWS PE - MENU INICIAL

:MENU
cls
echo ==========================================================
echo                WINDOWS PE - MENU INICIAL
echo ==========================================================
echo.
echo  [1] Abrir Explorer++ (recomendado)
echo  [2] Iniciar Windows NT Setup
echo  [3] Executar Script DiskPart
echo  [4] Executar Script de Particionamento
echo.
echo  [5] Reiniciar
echo  [6] Desligar
echo.
set /p OPCAO=Selecione uma opcao: 

if "%OPCAO%"=="1" goto EXPLORERPP
if "%OPCAO%"=="2" goto NTSETUP
if "%OPCAO%"=="3" goto DISKPART
if "%OPCAO%"=="4" goto PSPART
if "%OPCAO%"=="5" goto REBOOT
if "%OPCAO%"=="6" goto SHUTDOWN

echo.
echo Opcao invalida.
ping -n 2 127.0.0.1 >nul
goto MENU

:: ----------------------------------------------------------
:: Opcoes
:: ----------------------------------------------------------

:EXPLORERPP
start X:\Windows\System32\Explorer++-x64.exe
goto MENU

:NTSETUP
start X:\Windows\System32\WinNTSetup_x64.exe
goto MENU

:DISKPART
call X:\Windows\System32\Scripts\script-diskpart.bat
goto MENU

:PSPART
call X:\Windows\System32\Scripts\gerenciador-particoes.cmd
goto MENU

:REBOOT
wpeutil reboot

:SHUTDOWN
wpeutil shutdown
