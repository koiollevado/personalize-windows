@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Criando Windows PE Personalizado - ADK
color 0A

:: ============================================================
:: Configurações
:: ============================================================
set "ARQUITETURA=amd64"
set "PASTA_WINPE=C:\winpe_amd64"
set "PASTA_CUSTOM=C:\winpe\X64"
set "IMAGEM_FUNDO=C:\winpe\winpe.jpg"
set "ISO_FINAL=C:\winpe_amd64.iso"

echo.
echo ========================================
echo  Criando Windows PE Personalizado
echo ========================================
echo.

:: Verifica Administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERRO] Execute como Administrador!
    pause
    exit /b 1
)

:: Configura ADK
echo [0/8] Configurando ambiente do ADK...
for %%I in ("%ProgramFiles(x86)%\Windows Kits\10\Assessment and Deployment Kit") do set "ADK_PATH=%%~sI"

if not exist "%ADK_PATH%\Deployment Tools\DandISetEnv.bat" (
    echo [ERRO] ADK nao encontrado.
    pause
    exit /b 1
)
call "%ADK_PATH%\Deployment Tools\DandISetEnv.bat"

:: ============================================================
:: 1. Limpeza antecipada forte
:: ============================================================
echo.
echo [1/8] Limpando montagens anteriores...
dism /Get-MountedImageInfo
dism /Cleanup-Wim >nul 2>&1
dism /Cleanup-Mountpoints >nul 2>&1

if exist "%PASTA_WINPE%\mount" (
    dism /Unmount-Image /MountDir:"%PASTA_WINPE%\mount" /Discard >nul 2>&1
)
dism /Cleanup-Wim >nul 2>&1
echo [OK] Limpeza concluida.

:: ============================================================
:: 2. Remover pasta antiga
:: ============================================================
echo.
echo [2/8] Removendo pasta de trabalho antiga...
if exist "%PASTA_WINPE%" (
    rmdir /S /Q "%PASTA_WINPE%" 2>nul
    if exist "%PASTA_WINPE%" (
        echo [ERRO] Nao foi possivel remover a pasta. Feche programas que a estejam usando.
        pause
        exit /b 1
    )
)
echo [OK] Pasta limpa.

:: ============================================================
:: 3. Criar estrutura com copype
:: ============================================================
echo.
echo [3/8] Criando estrutura base com copype...
call copype %ARQUITETURA% "%PASTA_WINPE%"
if errorlevel 1 (
    echo [ERRO] Falha no copype.
    pause
    exit /b 1
)
echo [OK] Estrutura criada.

:: ============================================================
:: 4. Montar boot.wim
:: ============================================================
echo.
echo [4/8] Montando boot.wim...
Dism /Mount-Image /ImageFile:"%PASTA_WINPE%\media\sources\boot.wim" /Index:1 /MountDir:"%PASTA_WINPE%\mount"
if errorlevel 1 (
    echo [ERRO] Falha ao montar boot.wim
    pause
    exit /b 1
)
echo [OK] Imagem montada.

:: ============================================================
:: 5. Criar startnet.cmd
:: ============================================================
echo.
echo [5/8] Criando startnet.cmd...
(
    echo @echo off
    echo wpeinit
    echo ping -n 3 127.0.0.1 ^>nul
    echo call X:\Windows\System32\menu.cmd
) > "%PASTA_WINPE%\mount\Windows\System32\startnet.cmd"
echo [OK] startnet.cmd criado.

:: ============================================================
:: 6. Copiar arquivos personalizados
:: ============================================================
echo.
echo [6/8] Copiando arquivos personalizados...
if exist "%PASTA_CUSTOM%" (
    xcopy "%PASTA_CUSTOM%\*" "%PASTA_WINPE%\mount\Windows\System32\" /E /H /K /Y >nul
    echo [OK] Arquivos copiados.
) else (
    echo [AVISO] Pasta %PASTA_CUSTOM% nao encontrada.
)

:: ============================================================
:: 7. Substituir imagem de fundo
:: ============================================================
echo.
echo [7/8] Substituindo imagem de fundo...
if exist "%IMAGEM_FUNDO%" (
    takeown /f "%PASTA_WINPE%\mount\Windows\System32\winpe.jpg" /a >nul 2>&1
    icacls "%PASTA_WINPE%\mount\Windows\System32\winpe.jpg" /grant Administrators:F >nul 2>&1
    del /f /q "%PASTA_WINPE%\mount\Windows\System32\winpe.jpg" >nul 2>&1
    copy /Y "%IMAGEM_FUNDO%" "%PASTA_WINPE%\mount\Windows\System32\winpe.jpg" >nul
    echo [OK] Imagem substituida.
) else (
    echo [AVISO] %IMAGEM_FUNDO% nao encontrado.
)

:: ============================================================
:: 8. Desmontar + Gerar ISO
:: ============================================================
echo.
echo [8/8] Desmontando imagem e gerando ISO...
Dism /Unmount-Image /MountDir:"%PASTA_WINPE%\mount" /Commit
if errorlevel 1 (
    echo [ERRO] Falha no Commit. Tentando Discard...
    Dism /Unmount-Image /MountDir:"%PASTA_WINPE%\mount" /Discard >nul 2>&1
    Dism /Cleanup-Wim >nul 2>&1
    pause
    exit /b 1
)

echo [OK] Imagem desmontada.
echo Gerando ISO...
MakeWinPEMedia /ISO /f "%PASTA_WINPE%" "%ISO_FINAL%"
if errorlevel 1 (
    echo [ERRO] Falha ao gerar a ISO.
    pause
    exit /b 1
)

:: ============================================================
::                       Limpeza final
:: ============================================================
cls
echo.
echo Removendo pastas e arquivos 
echo.
del /q /f  C:\winpe\create_winpe_amd64.bat 2>nul
del /q /f  C:\winpe\create_winpe_amd64-iso.bat 2>nul
rmdir /s /q C:\winpe_amd64 2>nul
echo.
echo ========================================
echo  Processo concluido com sucesso!
echo  ISO gerada em: %ISO_FINAL%
echo ========================================
echo.
pause
exit /b 0