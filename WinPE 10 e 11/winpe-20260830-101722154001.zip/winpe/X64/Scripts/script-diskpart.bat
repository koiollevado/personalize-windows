@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul 2>&1

:: Atualizado em 20260827.

:: ============================================================
:: VERIFICACAO BASICA
:: ============================================================
if not exist "%SystemRoot%\System32\diskpart.exe" (
    echo ERRO: diskpart nao encontrado. Execute este script no Windows PE.
    pause
    exit /b 1
)

:MENU_INICIAL
:: Limpar arquivos e variaveis
if exist "X:\script-diskpart.txt" del /f /q "X:\script-diskpart.txt" >nul 2>&1
if exist "%TEMP%\list_disk.txt"   del /f /q "%TEMP%\list_disk.txt"   >nul 2>&1

set "REG_MODE="
set "BCD_MODE="
set "FWTYPE="
set "disco="
set "system_mb="
set "efi_mb="
set "win_gb="
set "win_mb="
set "dados_gb="
set "dados_mb="
set "rec_mb="
set "tipo_disco="
set "layout="
set "esquema="
set "conf="
set "valid="

cls
echo.
echo =============================================
echo  DETECCAO DE BIOS / UEFI  (Windows PE)
echo =============================================
echo.

:: =========================================================
:: 1. METODO PRINCIPAL - PEFirmwareType
:: =========================================================
set "REG_MODE=DESCONHECIDO"
set "FWTYPE="

for /f "tokens=3" %%A in ('
    reg query "HKLM\SYSTEM\CurrentControlSet\Control" /v PEFirmwareType 2^>nul ^| find "PEFirmwareType"
') do set "FWTYPE=%%A"

if /I "!FWTYPE!"=="0x1" set "REG_MODE=LEGACY"
if /I "!FWTYPE!"=="0x2" set "REG_MODE=UEFI"

:: =========================================================
:: 2. METODO COMPLEMENTAR - bcdedit
:: =========================================================
set "BCD_MODE=DESCONHECIDO"
for /f "tokens=*" %%A in ('bcdedit 2^>nul ^| find /I "path"') do (
    echo %%A | find /I "winload.efi" >nul 2>&1 && set "BCD_MODE=UEFI"
    echo %%A | find /I "winload.exe" >nul 2>&1 && set "BCD_MODE=LEGACY"
)

:: =========================================================
:: 3. RESULTADO FINAL
:: =========================================================
if /I "!REG_MODE!"=="UEFI" (
    echo =============================================
    echo  S U G E S T A O
    echo ---------------------------------------------
    echo  Firmware UEFI detectado
    echo  Utilize particionamento GPT
    echo =============================================
) else if /I "!REG_MODE!"=="LEGACY" (
    echo =============================================
    echo  S U G E S T A O
    echo ---------------------------------------------
    echo  Firmware Legacy BIOS detectado
    echo  Utilize particionamento MBR
    echo =============================================
) else (
    echo =============================================
    echo  ATENCAO: Nao foi possivel determinar com
    echo  seguranca o modo de firmware.
    echo.
    echo  REG QUERY = !REG_MODE!
    echo  BCDEDIT   = !BCD_MODE!
    echo.
    echo  Escolha o particionamento manualmente.
    echo =============================================
)

echo.
pause

:MENU_ESQUEMA
cls
echo =============================================
echo  Selecione o particionamento de disco
echo =============================================
echo.
echo  MBR (Legacy / BIOS)
echo ---------------------------------------------
echo  1. System + Windows
echo  2. System + Windows + Dados
echo  3. System + Windows + Recovery
echo  4. System + Windows + Recovery + Dados
echo ---------------------------------------------
echo  GPT (UEFI)
echo ---------------------------------------------
echo  5. EFI + Windows
echo  6. EFI + Windows + Dados
echo  7. EFI + Windows + Recovery
echo  8. EFI + Windows + Recovery + Dados
echo ---------------------------------------------
echo  0. Sair
echo =============================================
echo.
set /p "esquema= Escolha: "

if "%esquema%"=="1" goto MBR_SW
if "%esquema%"=="2" goto MBR_SWD
if "%esquema%"=="3" goto MBR_SWR
if "%esquema%"=="4" goto MBR_SWRD
if "%esquema%"=="5" goto GPT_EW
if "%esquema%"=="6" goto GPT_EWD
if "%esquema%"=="7" goto GPT_EWR
if "%esquema%"=="8" goto GPT_EWRD
if "%esquema%"=="0" goto SAIR

echo.
echo  Opcao invalida.
ping -n 3 127.0.0.1 >nul
goto MENU_ESQUEMA

:: ============================================================
:: FUNCAO: Validar se e numero (sem findstr)
:: ============================================================
:VALIDAR_NUMERO
set "valid=1"
for /f "delims=0123456789" %%A in ("!%~1!") do set "valid=0"
goto :eof

:: ============================================================
:: CAPTURAR DISCO
:: ============================================================
:DEFINIR_DISCO
set "disco="
cls
echo.
echo --------------------------------------------------------
echo             D I S C O S    L I S T A D O S
echo --------------------------------------------------------
echo   Disco N    Status         Tam.       Livre       GPT
echo   -------    ------         -------    -----       ---
echo.
echo list disk | diskpart | find "Disk " | find "B"
echo.
echo --------------------------------------------------------
echo.
set /p "disco= Informe o numero do disco: "

call :VALIDAR_NUMERO disco
if "!valid!"=="0" (
    echo.
    echo  Numero de disco invalido.
    ping -n 3 127.0.0.1 >nul
    goto DEFINIR_DISCO
)
goto %1

:: ============================================================
:: CAPTURA DE TAMANHOS
:: ============================================================
:ASK_WINDOWS
cls
echo.
echo =============================================
echo  Defina a particao Windows
echo =============================================
echo.
set /p "win_gb= Informe o tamanho em GB: "

call :VALIDAR_NUMERO win_gb
if "!valid!"=="0" (
    echo  Valor invalido.
    ping -n 3 127.0.0.1 >nul
    goto ASK_WINDOWS
)

set /a win_mb=win_gb*1024
if !win_mb! LSS 10240 (
    echo.
    echo  Aviso: menos de 10 GB pode ser insuficiente.
    ping -n 3 127.0.0.1 >nul
)
goto %1

:ASK_RECOVERY
cls
echo.
echo =============================================
echo  Defina a particao Recovery
echo =============================================
echo  S U G E S T O E S
echo ---------------------------------------------
echo  500-1024 MB  - recomendado atual
echo  380 MB       - Win10 Ent 2016 LTSB x64
echo  460 MB       - Win10 Pro 22H2 x64
echo  350 MB       - Win10 Pro/Home 21H1 x86
echo ---------------------------------------------
echo.
set /p "rec_mb= Informe o tamanho em MB: "

call :VALIDAR_NUMERO rec_mb
if "!valid!"=="0" (
    echo  Valor invalido.
    ping -n 3 127.0.0.1 >nul
    goto ASK_RECOVERY
)

if !rec_mb! LSS 300 (
    echo.
    echo  Aviso: menos de 300 MB pode ser insuficiente.
    ping -n 3 127.0.0.1 >nul
)
goto %1

:: ============================================================
:: MBR - SYSTEM + WINDOWS
:: ============================================================
:MBR_SW
set "system_mb=100"
set "tipo_disco=MBR"
set "layout=System + Windows"
call :DEFINIR_DISCO MBR_SW_CONT
goto :eof

:MBR_SW_CONT
(
echo select disk %disco%
echo clean
echo convert mbr
echo create partition primary size=%system_mb%
echo format quick fs=ntfs label="System"
echo assign letter=S
echo active
echo create partition primary
echo format quick fs=ntfs label="Windows"
echo assign letter=W
echo exit
) > "X:\script-diskpart.txt"
goto EXECUTAR

:: ============================================================
:: MBR - SYSTEM + WINDOWS + DADOS
:: ============================================================
:MBR_SWD
set "system_mb=100"
set "tipo_disco=MBR"
set "layout=System + Windows + Dados"
call :DEFINIR_DISCO MBR_SWD_ASK_WINDOWS
goto :eof

:MBR_SWD_ASK_WINDOWS
call :ASK_WINDOWS MBR_SWD_CONT
goto :eof

:MBR_SWD_CONT
(
echo select disk %disco%
echo clean
echo convert mbr
echo create partition primary size=%system_mb%
echo format quick fs=ntfs label="System"
echo assign letter=S
echo active
echo create partition primary size=%win_mb%
echo format quick fs=ntfs label="Windows"
echo assign letter=W
echo create partition primary
echo format quick fs=ntfs label="Dados"
echo assign letter=D
echo exit
) > "X:\script-diskpart.txt"
goto EXECUTAR

:: ============================================================
:: MBR - SYSTEM + WINDOWS + RECOVERY
:: ============================================================
:MBR_SWR
set "system_mb=100"
set "tipo_disco=MBR"
set "layout=System + Windows + Recovery"
call :DEFINIR_DISCO MBR_SWR_ASK_RECOVERY
goto :eof

:MBR_SWR_ASK_RECOVERY
call :ASK_RECOVERY MBR_SWR_CONT
goto :eof

:MBR_SWR_CONT
(
echo select disk %disco%
echo clean
echo convert mbr
echo create partition primary size=%system_mb%
echo format quick fs=ntfs label="System"
echo assign letter=S
echo active
echo create partition primary
echo shrink desired=%rec_mb%
echo format quick fs=ntfs label="Windows"
echo assign letter=W
echo create partition primary size=%rec_mb%
echo format quick fs=ntfs label="Recovery"
echo assign letter=R
echo set id=27
echo exit
) > "X:\script-diskpart.txt"
goto EXECUTAR

:: ============================================================
:: MBR - SYSTEM + WINDOWS + RECOVERY + DADOS
:: ============================================================
:MBR_SWRD
set "system_mb=100"
set "tipo_disco=MBR"
set "layout=System + Windows + Recovery + Dados"
call :DEFINIR_DISCO MBR_SWRD_ASK_RECOVERY
goto :eof

:MBR_SWRD_ASK_RECOVERY
call :ASK_RECOVERY MBR_SWRD_ASK_WINDOWS
goto :eof

:MBR_SWRD_ASK_WINDOWS
call :ASK_WINDOWS MBR_SWRD_CONT
goto :eof

:MBR_SWRD_CONT
(
echo select disk %disco%
echo clean
echo convert mbr
echo create partition primary size=%system_mb%
echo format quick fs=ntfs label="System"
echo assign letter=S
echo active
echo create partition primary size=%win_mb%
echo format quick fs=ntfs label="Windows"
echo assign letter=W
echo create partition primary size=%rec_mb%
echo format quick fs=ntfs label="Recovery"
echo assign letter=R
echo set id=27
echo create partition primary
echo format quick fs=ntfs label="Dados"
echo assign letter=D
echo exit
) > "X:\script-diskpart.txt"
goto EXECUTAR

:: ============================================================
:: GPT - EFI + WINDOWS
:: ============================================================
:GPT_EW
set "efi_mb=100"
set "tipo_disco=GPT"
set "layout=EFI + Windows"
call :DEFINIR_DISCO GPT_EW_CONT
goto :eof

:GPT_EW_CONT
(
echo select disk %disco%
echo clean
echo convert gpt
echo create partition efi size=%efi_mb%
echo format quick fs=fat32 label="EFI"
echo assign letter=S
echo create partition msr size=16
echo create partition primary
echo format quick fs=ntfs label="Windows"
echo assign letter=W
echo exit
) > "X:\script-diskpart.txt"
goto EXECUTAR

:: ============================================================
:: GPT - EFI + WINDOWS + DADOS
:: ============================================================
:GPT_EWD
set "efi_mb=100"
set "tipo_disco=GPT"
set "layout=EFI + Windows + Dados"
call :DEFINIR_DISCO GPT_EWD_ASK_WINDOWS
goto :eof

:GPT_EWD_ASK_WINDOWS
call :ASK_WINDOWS GPT_EWD_CONT
goto :eof

:GPT_EWD_CONT
(
echo select disk %disco%
echo clean
echo convert gpt
echo create partition efi size=%efi_mb%
echo format quick fs=fat32 label="EFI"
echo assign letter=S
echo create partition msr size=16
echo create partition primary size=%win_mb%
echo format quick fs=ntfs label="Windows"
echo assign letter=W
echo create partition primary
echo format quick fs=ntfs label="Dados"
echo assign letter=D
echo exit
) > "X:\script-diskpart.txt"
goto EXECUTAR

:: ============================================================
:: GPT - EFI + WINDOWS + RECOVERY
:: ============================================================
:GPT_EWR
set "efi_mb=100"
set "tipo_disco=GPT"
set "layout=EFI + Windows + Recovery"
call :DEFINIR_DISCO GPT_EWR_ASK_RECOVERY
goto :eof

:GPT_EWR_ASK_RECOVERY
call :ASK_RECOVERY GPT_EWR_CONT
goto :eof

:GPT_EWR_CONT
(
echo select disk %disco%
echo clean
echo convert gpt
echo create partition efi size=%efi_mb%
echo format quick fs=fat32 label="EFI"
echo assign letter=S
echo create partition msr size=16
echo create partition primary
echo shrink desired=%rec_mb%
echo format quick fs=ntfs label="Windows"
echo assign letter=W
echo create partition primary size=%rec_mb%
echo format quick fs=ntfs label="Recovery"
echo assign letter=R
echo set id=de94bba4-06d1-4d40-a16a-bfd50179d6ac
echo gpt attributes=0x8000000000000001
echo exit
) > "X:\script-diskpart.txt"
goto EXECUTAR

:: ============================================================
:: GPT - EFI + WINDOWS + RECOVERY + DADOS
:: ============================================================
:GPT_EWRD
set "efi_mb=100"
set "tipo_disco=GPT"
set "layout=EFI + Windows + Recovery + Dados"
call :DEFINIR_DISCO GPT_EWRD_ASK_RECOVERY
goto :eof

:GPT_EWRD_ASK_RECOVERY
call :ASK_RECOVERY GPT_EWRD_ASK_WINDOWS
goto :eof

:GPT_EWRD_ASK_WINDOWS
call :ASK_WINDOWS GPT_EWRD_CONT
goto :eof

:GPT_EWRD_CONT
(
echo select disk %disco%
echo clean
echo convert gpt
echo create partition efi size=%efi_mb%
echo format quick fs=fat32 label="EFI"
echo assign letter=S
echo create partition msr size=16
echo create partition primary size=%win_mb%
echo format quick fs=ntfs label="Windows"
echo assign letter=W
echo create partition primary size=%rec_mb%
echo format quick fs=ntfs label="Recovery"
echo assign letter=R
echo set id=de94bba4-06d1-4d40-a16a-bfd50179d6ac
echo gpt attributes=0x8000000000000001
echo create partition primary
echo format quick fs=ntfs label="Dados"
echo assign letter=D
echo exit
) > "X:\script-diskpart.txt"
goto EXECUTAR

:: ============================================================
:: RESUMO E CONFIRMACAO
:: ============================================================
:EXECUTAR
cls
echo =======================================
echo  RESUMO DA CONFIGURACAO
echo =======================================
echo.
echo  Tipo de disco     : !tipo_disco!
echo  Layout escolhido  : !layout!
echo  Disco selecionado : !disco!
echo.
echo ---------------------------------------
if defined system_mb echo  Particao System   : !system_mb! MB
if defined efi_mb    echo  Particao EFI      : !efi_mb! MB
if defined win_mb    echo  Particao Windows  : !win_gb! GB ^(!win_mb! MB^)
if defined rec_mb    echo  Particao Recovery : !rec_mb! MB

echo.
if "!layout!"=="System + Windows + Dados"              echo  Particao Dados    : *restante do disco*
if "!layout!"=="System + Windows + Recovery + Dados"   echo  Particao Dados    : *restante do disco*
if "!layout!"=="EFI + Windows + Dados"                 echo  Particao Dados    : *restante do disco*
if "!layout!"=="EFI + Windows + Recovery + Dados"      echo  Particao Dados    : *restante do disco*
if "!layout!"=="System + Windows + Recovery"           echo  Particao Windows  : *restante menos Recovery*
if "!layout!"=="EFI + Windows + Recovery"              echo  Particao Windows  : *restante menos Recovery*

echo.
echo ---------------------------------------
echo  Deseja manter esta configuracao?
echo ---------------------------------------
echo  S = Sim  (executa o Diskpart)
echo  N = Nao  (voltar ao menu)
echo =======================================
echo.
set /p "conf= Opcao: "

if /i "!conf!"=="N" goto MENU_INICIAL
if /i "!conf!"=="S" goto DISKPART

echo.
echo  Opcao invalida.
ping -n 3 127.0.0.1 >nul
goto EXECUTAR

:DISKPART
cls
echo.
echo =============================================
echo  Executando o Diskpart ...
echo =============================================
echo.

if not exist "X:\script-diskpart.txt" (
    echo  ERRO: X:\script-diskpart.txt nao encontrado.
    pause
    goto SAIR
)

diskpart /s "X:\script-diskpart.txt"
set "DP_ERROR=!errorlevel!"

echo.
echo =============================================
if !DP_ERROR! EQU 0 (
    echo  Processo concluido com sucesso.
) else (
    echo  Diskpart retornou codigo de erro: !DP_ERROR!
    echo  Verifique a saida acima.
)
echo =============================================
echo.
pause
goto SAIR

:SAIR
endlocal
exit /b