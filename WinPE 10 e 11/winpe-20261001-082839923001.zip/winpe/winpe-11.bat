@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Criando Windows PE Personalizado - ADK
color 0A

:: ============================================================
:: Configurações
:: ============================================================
set "ARQUITETURA=amd64"
set "PASTA_WINPE=C:\winpe_amd64"
set "ISO_ORIGEM=C:\iso-winpe-11\winpe_amd64.iso"
set "PASTA_CUSTOM=C:\winpe\X64"
set "IMAGEM_FUNDO=C:\winpe\winpe.jpg"
set "ISO_FINAL=C:\winpe_amd64.iso"

:: Caminho do 7-Zip
set "SETEZIP=C:\Program Files\7-Zip\7z.exe"
if not exist "%SETEZIP%" set "SETEZIP=C:\Program Files (x86)\7-Zip\7z.exe"

echo.
echo ========================================
echo  Criando Windows PE Personalizado
echo ========================================
echo.

:: Verifica Administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERRO] Execute este script como Administrador!
    pause
    exit /b 1
)

:: Verifica 7-Zip
if not exist "%SETEZIP%" (
    echo [ERRO] 7-Zip nao encontrado!
    pause
    exit /b 1
)

:: Configura ADK
echo [0/9] Configurando ambiente do ADK...
for %%I in ("%ProgramFiles(x86)%\Windows Kits\10\Assessment and Deployment Kit") do set "ADK_PATH=%%~sI"

if not exist "%ADK_PATH%\Deployment Tools\DandISetEnv.bat" (
    echo [ERRO] ADK nao encontrado.
    pause
    exit /b 1
)
call "%ADK_PATH%\Deployment Tools\DandISetEnv.bat"
if errorlevel 1 (
    echo [ERRO] Falha ao configurar o ADK.
    pause
    exit /b 1
)

:: ============================================================
:: 1. Limpeza antecipada
:: ============================================================
echo.
echo [1/9] Limpando montagens anteriores...
dism /Cleanup-Wim >nul 2>&1
dism /Cleanup-Mountpoints >nul 2>&1
if exist "%PASTA_WINPE%\mount" (
    dism /Unmount-Image /MountDir:"%PASTA_WINPE%\mount" /Discard >nul 2>&1
)
dism /Cleanup-Wim >nul 2>&1
echo [OK] Limpeza concluida.

:: ============================================================
:: 2. Remover pasta antiga
:: ============================================================
echo.
echo [2/9] Removendo pasta de trabalho antiga...
if exist "%PASTA_WINPE%" (
    rmdir /S /Q "%PASTA_WINPE%" 2>nul
)
echo [OK] Pasta limpa.

:: ============================================================
:: 3. Criar estrutura com copype
:: ============================================================
echo.
echo [3/9] Criando estrutura base com copype...
call copype %ARQUITETURA% "%PASTA_WINPE%"
if errorlevel 1 (
    echo [ERRO] Falha no copype.
    pause
    exit /b 1
)
echo [OK] Estrutura criada.

:: ============================================================
:: 4. Extrair ISO com 7-Zip
:: ============================================================
echo.
echo [4/9] Extraindo arquivos da ISO com 7-Zip...
if not exist "%ISO_ORIGEM%" (
    echo [ERRO] ISO nao encontrada: %ISO_ORIGEM%
    pause
    exit /b 1
)

"%SETEZIP%" x "%ISO_ORIGEM%" -o"%PASTA_WINPE%\media" -y
if errorlevel 1 (
    echo [ERRO] Falha ao extrair a ISO com 7-Zip.
    pause
    exit /b 1
)
echo [OK] Arquivos da ISO extraidos com sucesso.

:: ============================================================
:: 5. Remover pastas de idioma
:: ============================================================
echo.
echo [5/9] Removendo pastas de idioma extras...
for /D %%i in ("%PASTA_WINPE%\media\*-*") do if /I "%%~nxi" NEQ "en-us" rmdir /S /Q "%%i" 2>nul
for /D %%i in ("%PASTA_WINPE%\media\Boot\*-*") do if /I "%%~nxi" NEQ "en-us" rmdir /S /Q "%%i" 2>nul
for /D %%i in ("%PASTA_WINPE%\media\EFI\Microsoft\Boot\*-*") do if /I "%%~nxi" NEQ "en-us" rmdir /S /Q "%%i" 2>nul
echo [OK] Limpeza de idiomas concluida.

:: ============================================================
:: 6. Montar boot.wim
:: ============================================================
echo.
echo [6/9] Montando boot.wim...
if exist "%PASTA_WINPE%\mount\*" (
    rmdir /S /Q "%PASTA_WINPE%\mount" 2>nul
    mkdir "%PASTA_WINPE%\mount" >nul
)

Dism /Mount-Image /ImageFile:"%PASTA_WINPE%\media\sources\boot.wim" /Index:1 /MountDir:"%PASTA_WINPE%\mount"
if errorlevel 1 (
    echo [ERRO] Falha ao montar boot.wim
    pause
    exit /b 1
)
echo [OK] Imagem montada.

:: ============================================================
:: 7. Criar startnet.cmd
:: ============================================================
echo.
echo [7/9] Criando startnet.cmd...
(
    echo @echo off
    echo wpeinit
    echo ping -n 3 127.0.0.1 ^>nul
    echo call X:\Windows\System32\menu.cmd
) > "%PASTA_WINPE%\mount\Windows\System32\startnet.cmd"
echo [OK] startnet.cmd criado.

:: ============================================================
:: 8. Copiar arquivos personalizados + imagem de fundo
:: ============================================================
echo.
echo [8/9] Copiando arquivos personalizados e imagem de fundo...

if exist "%PASTA_CUSTOM%" (
    xcopy "%PASTA_CUSTOM%\*" "%PASTA_WINPE%\mount\Windows\System32\" /E /H /K /Y >nul
    echo [OK] Arquivos personalizados copiados.
) else (
    echo [AVISO] Pasta %PASTA_CUSTOM% nao encontrada.
)

if exist "%IMAGEM_FUNDO%" (
    takeown /f "%PASTA_WINPE%\mount\Windows\System32\winpe.jpg" /a >nul 2>&1
    icacls "%PASTA_WINPE%\mount\Windows\System32\winpe.jpg" /grant Administrators:F >nul 2>&1
    del /f /q "%PASTA_WINPE%\mount\Windows\System32\winpe.jpg" >nul 2>&1
    copy /Y "%IMAGEM_FUNDO%" "%PASTA_WINPE%\mount\Windows\System32\winpe.jpg" >nul
    echo [OK] Imagem de fundo substituida.
) else (
    echo [AVISO] %IMAGEM_FUNDO% nao encontrado.
)

:: ============================================================
:: 9. Desmontar e gerar ISO
:: ============================================================
echo.
echo [9/9] Desmontando imagem e gerando ISO final...
Dism /Unmount-Image /MountDir:"%PASTA_WINPE%\mount" /Commit
if errorlevel 1 (
    echo [ERRO] Falha no /Commit.
    Dism /Unmount-Image /MountDir:"%PASTA_WINPE%\mount" /Discard >nul 2>&1
    Dism /Cleanup-Wim >nul 2>&1
    pause
    exit /b 1
)

echo [OK] Imagem desmontada.
echo.
echo Gerando ISO: %ISO_FINAL%
MakeWinPEMedia /ISO /f "%PASTA_WINPE%" "%ISO_FINAL%"
if errorlevel 1 (
    echo [ERRO] Falha ao gerar a ISO.
    pause
    exit /b 1
)

:: ============================================================
:: Limpeza final (conforme solicitado)
:: ============================================================
cls
echo.
echo Removendo pastas e arquivos 
echo.
del /q /f  C:\winpe\create_winpe_amd64.bat 2>nul
del /q /f  C:\winpe\create_winpe_amd64-iso.bat 2>nul
rmdir /s /q C:\winpe_amd64 2>nul

echo.
echo ========================================
echo  Processo concluido com sucesso!
echo  ISO gerada em: %ISO_FINAL%
echo ========================================
echo.
pause
exit /b 0