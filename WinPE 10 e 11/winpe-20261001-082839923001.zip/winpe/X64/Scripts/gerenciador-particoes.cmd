@echo off
setlocal EnableDelayedExpansion
title GERENCIADOR DE PARTICOES - DISKPART

:MENU
cls
echo ============================================
echo      GERENCIADOR DE PARTICOES (WinPE)
echo ============================================
echo.
echo [1] Reduzir particao existente
echo [2] Remover particao e expandir outra
echo [3] Criar nova particao
echo.
echo [0] Voltar
echo.
set /p OP=Escolha uma opcao: 

if "%OP%"=="1" goto REDUZIR
if "%OP%"=="2" goto REMOVER_EXPANDIR
if "%OP%"=="3" goto CRIAR
if "%OP%"=="0" exit /b

goto MENU

:: =====================================================
:: OP��O 1 - REDUZIR PARTI��O
:: =====================================================
:REDUZIR
cls
echo === REDUZIR PARTICAO ===
echo.
echo Discos e particoes:
echo.
diskpart /s "%~dp0\listar.txt"
echo.

set /p DISK=Numero do disco:
set /p PART=Numero da particao:
set /p TAMGB=Quanto deseja REDUZIR (em GB):

:: Convers�o GB -> MB
set /a TAMMB=%TAMGB%*1024

cls
echo === CONFIRMACAO ===
echo Disco.............: %DISK%
echo Particao..........: %PART%
echo Reducao...........: %TAMGB% GB (%TAMMB% MB)
echo.
set /p CONF=Confirmar operacao? (S/N): 

if /I not "%CONF%"=="S" goto MENU

(
echo select disk %DISK%
echo select partition %PART%
echo shrink desired=%TAMMB%
) > X:\shrink.txt

diskpart /s X:\shrink.txt
del X:\shrink.txt

pause
goto MENU

:: =====================================================
:: OP��O 2 - REMOVER E EXPANDIR
:: =====================================================
:REMOVER_EXPANDIR
cls
echo === REMOVER E EXPANDIR PARTICAO ===
echo.
diskpart /s "%~dp0\listar.txt"
echo.

set /p DISK=Numero do disco:
set /p PARTREM=Particao a REMOVER:
set /p PARTEXP=Particao a EXPANDIR:

cls
echo === CONFIRMACAO ===
echo Disco................: %DISK%
echo Particao a remover....: %PARTREM%
echo Particao a expandir..: %PARTEXP%
echo.
set /p CONF=Confirmar operacao? (S/N): 

if /I not "%CONF%"=="S" goto MENU

(
echo select disk %DISK%
echo select partition %PARTREM%
echo delete partition override
echo select partition %PARTEXP%
echo extend
) > X:\expand.txt

diskpart /s X:\expand.txt
del X:\expand.txt

pause
goto MENU

:: =====================================================
:: OP��O 3 - CRIAR NOVA PARTI��O
:: =====================================================
:CRIAR
cls
echo === CRIAR NOVA PARTICAO ===
echo.
diskpart /s "%~dp0\listar.txt"
echo.

set /p DISK=Numero do disco:
set /p TAMGB=Tamanho da nova particao (GB):
set /p LETRA=Letra da unidade:
set /p LABEL=Rotulo da particao:

:: Convers�o GB -> MB
set /a TAMMB=%TAMGB%*1024

cls
echo === CONFIRMACAO ===
echo Disco.............: %DISK%
echo Tamanho...........: %TAMGB% GB (%TAMMB% MB)
echo Letra.............: %LETRA%
echo Rotulo............: %LABEL%
echo.
set /p CONF=Confirmar operacao? (S/N): 

if /I not "%CONF%"=="S" goto MENU

(
echo select disk %DISK%
echo create partition primary size=%TAMMB%
echo format fs=ntfs quick label="%LABEL%"
echo assign letter=%LETRA%
) > X:\create.txt

diskpart /s X:\create.txt
del X:\create.txt

pause
goto MENU
 
