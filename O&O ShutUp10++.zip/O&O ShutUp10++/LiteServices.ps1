# LiteServices.ps1
# Script para desativar serviços do Windows que não são essenciais
# Recomendado executar como Administrador

# Lista de serviços para desativar (apenas se não forem usados)
$services = @(
    "DiagTrack",        # Telemetria
    "dmwappushservice", # Serviço de Telemetria adicional
    "WMPNetworkSvc",    # Compartilhamento de mídia Windows Media Player
    "XblAuthManager",   # Xbox
    "XblGameSave",      # Xbox
    "XboxNetApiSvc",    # Xbox
    "XboxGipSvc",       # Xbox
    "Fax",              # Fax
    "Spooler",          # Impressão (desativar se não imprime)
    "RemoteRegistry",   # Registro remoto
    "MapsBroker",       # Serviços de mapas
    "lfsvc",            # Localização
    "SharedAccess",     # ICS (Internet Connection Sharing)
    "stisvc"            # Serviço de aquisição de imagens (desativar se não usa scanner/câmera antiga)
)

foreach ($svc in $services) {
    Write-Output "Desativando serviço: $svc"
    Stop-Service -Name $svc -ErrorAction SilentlyContinue
    Set-Service -Name $svc -StartupType Disabled -ErrorAction SilentlyContinue
}

Write-Output "Serviços desativados com sucesso. Reinicie o PC para aplicar totalmente."
