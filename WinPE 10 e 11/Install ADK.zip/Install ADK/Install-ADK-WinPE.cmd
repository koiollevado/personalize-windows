@echo off
setlocal

:: Caminho onde estao os instaladores
set ADK_PATH=C:\Installers

echo ============================================
echo Instalando Windows ADK (Deployment Tools)
echo ============================================

"%ADK_PATH%\adksetup.exe" ^
 /quiet ^
 /norestart ^
 /features OptionId.DeploymentTools

if errorlevel 1 (
    echo ERRO ao instalar o Windows ADK.
    exit /b 1
)

echo.
echo ============================================
echo Instalando Windows PE Add-on
echo ============================================

"%ADK_PATH%\adkwinpesetup.exe" ^
 /quiet ^
 /norestart

if errorlevel 1 (
    echo ERRO ao instalar o WinPE Add-on.
    exit /b 1
)

echo.
echo Instalacao do ADK + WinPE concluida com sucesso.
endlocal
 
